---
title: Promociona tu musica en Instagram Reels
description: Reels es una nueva sección que fue agregada recientemente por Instagram. En esta sección podrás crear vídeos cortos a partir de pistas de audio y vídeo y compartirlos con la comunidad.
img: promociona-tu-musica-en-instagram-reels.jpg
author:
    name: Xpend Music
    image: https://cdn.xpendmusic.com/media/img/artist/frankalvarez.jpg
---

**Reels** es una nueva sección que fue agregada recientemente por **Instagram**. En esta sección podrás crear vídeos cortos a partir de pistas de audio y vídeo y compartirlos con la comunidad.

Primero debes de tener distribuida tu música en **Instagram**, para que así puedas empezar a crear un vídeo creativo que llame la atención de las demás personas y así puedas generar ese interés de crear un vídeo similar con tu música.

Luego de subir tu vídeo tendrás la posibilidad de que tu vídeo pueda aparecer en la seccion *Explorar* donde podrán encontrarte personas que no te conozcan como artista. Todo esto es una gran oportunidad que no debes de perderte, por lo menos inténtalo.

> Si no tienes tu musica disponible en Instagram, puedes agregarla manualmente en un editor de video.